#!/bin/sh

7z a $archive_name "${@}"
