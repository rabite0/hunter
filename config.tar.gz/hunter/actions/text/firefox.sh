#!/bin/sh

firefox "$@"
