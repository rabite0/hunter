#!/bin/sh

firefox "${@}"
