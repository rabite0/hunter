#!/bin/sh

nano "$@"
