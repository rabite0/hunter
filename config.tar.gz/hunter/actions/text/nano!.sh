#!/bin/sh

nano "${@}"
