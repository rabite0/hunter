#!/bin/sh

exec mpv "${@}"
