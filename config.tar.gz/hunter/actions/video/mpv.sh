#!/bin/sh

exec mpv "$@"
