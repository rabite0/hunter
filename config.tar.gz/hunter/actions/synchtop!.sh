#!/bin/sh

exec htop
